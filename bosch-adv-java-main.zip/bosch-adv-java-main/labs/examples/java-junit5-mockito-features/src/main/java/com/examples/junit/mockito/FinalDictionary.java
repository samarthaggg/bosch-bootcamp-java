package com.examples.junit.mockito;

public final class FinalDictionary extends MyDictionary {
    public int size() {
        return this.wordMap.size();
    }
}
