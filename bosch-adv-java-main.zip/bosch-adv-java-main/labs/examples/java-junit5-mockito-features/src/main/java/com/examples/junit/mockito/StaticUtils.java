package com.examples.junit.mockito;

public class StaticUtils {
}
