package com.examples.java.annotation;

import java.lang.annotation.Documented;

@Documented
public @interface MetaAnnotation3 {

    // Indicates that an annotation should be included in the generated JavaDoc for the annotated elements.
}
