package com.examples.java.java17.record;

public record EmployeeRecord(int id,
                      String name,
                      String department,
                      String designation,
                      String country){}