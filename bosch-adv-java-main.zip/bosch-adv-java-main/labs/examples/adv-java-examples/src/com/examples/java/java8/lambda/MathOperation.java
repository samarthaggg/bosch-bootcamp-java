package com.examples.java.java8.lambda;

@FunctionalInterface
public interface MathOperation {
    public int calculate(int a, int b);
//    public int print(int a, int b);

}
