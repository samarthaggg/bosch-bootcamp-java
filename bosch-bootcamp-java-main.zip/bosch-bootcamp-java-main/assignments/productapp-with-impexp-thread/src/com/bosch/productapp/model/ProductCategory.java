package com.bosch.productapp.model;

public enum ProductCategory {
    MOBILES, LAPTOPS, FURNITURES, STATIONARY;
}
