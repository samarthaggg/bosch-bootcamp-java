package com.labs.java.annotations;

@SuppressWarnings("deprecation")
public class AnnotationsDemo {

    public static void main(String[] args) {
        Printer printer = new Printer();
        printer.print();
    }

}
