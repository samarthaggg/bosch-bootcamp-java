package com.labs.java.io;

public enum ProductCategory {
    MOBILES, LAPTOPS, FURNITURES, STATIONARY;
}
