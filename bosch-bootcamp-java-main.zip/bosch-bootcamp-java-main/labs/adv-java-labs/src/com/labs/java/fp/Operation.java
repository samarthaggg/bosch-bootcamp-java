package com.labs.java.fp;

//@FunctionalInterface
public interface Operation {
    int compute(int a, int b);
}
