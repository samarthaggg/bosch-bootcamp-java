package com.labs.java.stream;

public enum ProductCategory {
    MOBILES, LAPTOPS, FURNITURES, STATIONARY;
}
