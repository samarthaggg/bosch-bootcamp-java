package com.labs.java.annotations;

@FunctionalInterface
public interface FunctionalInterfaceDemo {
    public void process();
}
