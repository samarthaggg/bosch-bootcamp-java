package com.bosch.infotainment.navigation;

public class NavigationServiceImpl implements NavigationService {
    public String getCoordinates() {
        return "Coordinates: 12.9716° N, 77.5946° E";
    }
}
