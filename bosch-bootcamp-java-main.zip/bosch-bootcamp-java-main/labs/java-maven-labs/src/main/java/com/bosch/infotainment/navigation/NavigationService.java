package com.bosch.infotainment.navigation;

public interface NavigationService {
    public String getCoordinates();
}
