package com.labs.java.core.oops;

public class AccountConstants {
    public static final double SAVINGS_INTEREST_RATE = 0.04;
    public static final double DEPOSIT_INTEREST_RATE = 0.07;

}
