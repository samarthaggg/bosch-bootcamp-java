package com.labs.java.core.oops;

public interface Closeable {
}
