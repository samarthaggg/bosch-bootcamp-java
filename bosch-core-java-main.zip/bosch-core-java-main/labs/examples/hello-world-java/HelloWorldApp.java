/**
* First Java Program Demo
*/
public class HelloWorldApp {
	// main method
	public static void main(String[] args) throws InterruptedException {
		/* print statement
		* demo
      */
		System.out.println("Hello World!!!");

		Thread.sleep(5*60*1000);
	}
}