# bosch-core-java
Contains course materials, presentations, lab exercises and reference guides for Core Java training
